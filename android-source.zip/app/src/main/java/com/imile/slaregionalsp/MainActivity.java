package com.imile.slaregionalsp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
 private static final String ORIGIN="https://appassets.androidplatform.net";
 private static final String HOME=ORIGIN+"/index.html";
 private WebView web;
 private ValueCallback<Uri[]> fileCallback;
 private byte[] pendingPng;
 private boolean fileRequestActive=false;
 private static final int PICK_EXCEL=100, SAVE_IMAGE=101;

 @Override public void onCreate(Bundle state){
  super.onCreate(state);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(0,67,147));root.setFitsSystemWindows(true);
  LinearLayout bar=new LinearLayout(this);bar.setPadding(16,4,12,4);bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
  TextView title=new TextView(this);title.setText("iMile SLA SP");title.setTextColor(Color.WHITE);title.setTextSize(17);title.setTypeface(null,android.graphics.Typeface.BOLD);
  bar.addView(title,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
  Button reload=new Button(this);reload.setText("Atualizar");reload.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Atualizar painel?").setMessage("O relatório online será carregado após o login. Uma importação local ainda não salva poderá ser descartada.").setPositiveButton("Atualizar",(d,w)->web.reload()).setNegativeButton("Cancelar",null).show());bar.addView(reload);
  root.addView(bar);web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1));setContentView(root);
  WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setSupportMultipleWindows(false);
  web.addJavascriptInterface(new PngExporter(),"AndroidDownloads");
  web.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
    Uri uri=request.getUrl();if(!"appassets.androidplatform.net".equals(uri.getHost()))return null;
    String path=uri.getPath();if(path==null||path.equals("/"))path="/index.html";
    String name=path.substring(1);if(!name.matches("[A-Za-z0-9._-]+"))return new WebResourceResponse("text/plain","UTF-8",404,"Not found",null,null);
    try {String ext=name.substring(name.lastIndexOf('.')+1).toLowerCase(Locale.ROOT);String type=ext.equals("js")?"application/javascript":ext.equals("css")?"text/css":ext.equals("html")?"text/html":MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);return new WebResourceResponse(type==null?"application/octet-stream":type,"UTF-8",getAssets().open(name));}
    catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not found",null,null);}
   }
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
    Uri uri=request.getUrl();if("https".equals(uri.getScheme())&&"appassets.androidplatform.net".equals(uri.getHost()))return false;
    if("https".equals(uri.getScheme())||"mailto".equals(uri.getScheme())){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o link.",Toast.LENGTH_LONG).show();}}return true;
   }
  });
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
    if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
    Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("*/*");pick.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel"});
    try{fileRequestActive=true;startActivityForResult(pick,PICK_EXCEL);}catch(Exception e){fileRequestActive=false;fileCallback.onReceiveValue(null);fileCallback=null;Toast.makeText(MainActivity.this,"Não foi possível abrir o seletor de arquivos.",Toast.LENGTH_LONG).show();}return true;
   }
  });
  if(state==null||web.restoreState(state)==null)web.loadUrl(HOME);
 }
 private class PngExporter {
  @JavascriptInterface public void savePng(String encoded,String filename){
   if(encoded==null||encoded.length()>60_000_000)return;
   try{byte[] image=Base64.decode(encoded,Base64.DEFAULT);if(image.length<8||image[0]!=(byte)0x89||image[1]!=0x50||image[2]!=0x4e||image[3]!=0x47)return;
    runOnUiThread(()->{if(fileRequestActive){Toast.makeText(MainActivity.this,"Conclua a seleção de arquivo primeiro.",Toast.LENGTH_SHORT).show();return;}pendingPng=image;Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);save.addCategory(Intent.CATEGORY_OPENABLE);save.setType("image/png");save.putExtra(Intent.EXTRA_TITLE,(filename==null?"iMile.png":filename).replaceAll("[^A-Za-z0-9._-]","_"));try{fileRequestActive=true;startActivityForResult(save,SAVE_IMAGE);}catch(Exception e){pendingPng=null;fileRequestActive=false;Toast.makeText(MainActivity.this,"Não foi possível salvar a imagem.",Toast.LENGTH_LONG).show();}});
   }catch(Exception ignored){}
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);fileRequestActive=false;
  if(request==PICK_EXCEL&&fileCallback!=null){Uri[] uris=result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null;fileCallback.onReceiveValue(uris);fileCallback=null;}
  if(request==SAVE_IMAGE){byte[] image=pendingPng;pendingPng=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null&&image!=null){try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){if(stream==null)throw new Exception();stream.write(image);Toast.makeText(this,"Imagem salva.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Não foi possível salvar a imagem.",Toast.LENGTH_LONG).show();}}}
 }
 @Override protected void onSaveInstanceState(Bundle state){web.saveState(state);super.onSaveInstanceState(state);}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(fileCallback!=null)fileCallback.onReceiveValue(null);web.removeJavascriptInterface("AndroidDownloads");web.destroy();super.onDestroy();}
}
