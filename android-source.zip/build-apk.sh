#!/usr/bin/env bash
set -euo pipefail
sdk_path="${ANDROID_HOME:?Android SDK unavailable}"
tools_path="$(find "$sdk_path/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"
platform_jar="$(find "$sdk_path/platforms" -name android.jar | sort -V | tail -1)"
test -n "$platform_jar"
mkdir -p build/classes build/gen build/dex out
"$tools_path/aapt2" compile --dir app/src/main/res -o build/resources.zip
"$tools_path/aapt2" link -o build/base.apk -I "$platform_jar" --manifest app/src/main/AndroidManifest.xml --java build/gen -A app/src/main/assets build/resources.zip
find app/src/main/java build/gen -name '*.java' > build/sources.txt
javac -encoding UTF-8 -source 8 -target 8 -classpath "$platform_jar" -d build/classes @build/sources.txt
mapfile -t class_files < <(find build/classes -name '*.class')
"$tools_path/d8" --lib "$platform_jar" --min-api 26 --output build/dex "${class_files[@]}"
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -j ../unsigned.apk classes*.dex)
"$tools_path/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
# Chave privada gerada na compilação; não entra no APK ou no repositório público.
signing_password="$(openssl rand -hex 24)"
mkdir -p signing
printf '%s' "$signing_password" > build/signing-password.txt
keytool -genkeypair -keystore signing/imile-sla.jks -alias imile-sla -storepass "$signing_password" -keypass "$signing_password" -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=iMile SLA SP App"
export APK_SIGN_PASSWORD="$signing_password"
"$tools_path/apksigner" sign --ks signing/imile-sla.jks --ks-key-alias imile-sla --ks-pass env:APK_SIGN_PASSWORD --key-pass env:APK_SIGN_PASSWORD --out out/iMile-SLA-SP.apk build/aligned.apk
"$tools_path/apksigner" verify --verbose out/iMile-SLA-SP.apk
"$tools_path/aapt2" dump badging out/iMile-SLA-SP.apk > out/apk-info.txt
head -8 out/apk-info.txt
sha256sum out/iMile-SLA-SP.apk > out/SHA256.txt
openssl pkeyutl -encrypt -pubin -inkey signing-recipient.pub -in build/signing-password.txt -out signing/password.enc -pkeyopt rsa_padding_mode:oaep -pkeyopt rsa_oaep_md:sha256 -pkeyopt rsa_mgf1_md:sha256
